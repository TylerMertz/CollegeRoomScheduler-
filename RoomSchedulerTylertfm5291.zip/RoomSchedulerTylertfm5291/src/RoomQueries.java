import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;
import java.sql.Timestamp;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */
public class RoomQueries
{
    
   private static Connection connection;
   private static ArrayList<String> possibleRooms = new ArrayList<String>();
   private static ArrayList<String> reservationNames = new ArrayList<String>();
   private static ArrayList<Integer> reservationSeats = new ArrayList<Integer>();
   private static ArrayList<Date> reservationDates = new ArrayList<Date>();
   private static ArrayList<Timestamp> reservationTimes = new ArrayList<Timestamp>();
   private static ResultSet resultSet;
   private static PreparedStatement getAllRooms;
   private static PreparedStatement getAllPossibleRooms;
   private static PreparedStatement addRoom;
   private static PreparedStatement dropRoom;
   private static PreparedStatement checkWaitlisted;
   
   // method for getting all possible rooms
   public ArrayList<RoomEntry> getAllRooms()
   {
       connection = DBConnection.getConnection();
       try (ResultSet resultSet = getAllRooms.executeQuery())
       {
       ArrayList<RoomEntry> rooms = new ArrayList<RoomEntry>();
       
       while (resultSet.next()) 
       {
           rooms.add(new RoomEntry(resultSet.getString("NAME"), resultSet.getInt("SEATS")));
       }
       
       return rooms;
       
    }

    catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
          
    return null;
   }
   
   //getting all rooms based on seat criteria
   public static ArrayList<String> getAllPossibleRooms(int seats)
   {   
       connection = DBConnection.getConnection();
       possibleRooms = new ArrayList<String>();
       try
       {
         getAllPossibleRooms = connection.prepareStatement("SELECT NAME FROM ROOMS WHERE SEATS >= ? ORDER BY SEATS ASC");
         getAllPossibleRooms.setInt(1, seats);
         resultSet = getAllPossibleRooms.executeQuery();
         
         while (resultSet.next())
         {
                possibleRooms.add(resultSet.getString("NAME")); 
         }    
       } 
       catch(SQLException sqlException)
       {
           sqlException.printStackTrace();
       }
       
       return possibleRooms;
    
   }
   
   //adds a room and cycles through waitlist to fill in reservations with the new room that are possible
   public static String addRoom(String name, int seats) 
   {
    connection = DBConnection.getConnection();
    String txt = "";
    reservationNames = new ArrayList<String>();
    reservationSeats = new ArrayList<Integer>();
    reservationDates = new ArrayList<Date>();
    reservationTimes = new ArrayList<Timestamp>();
    
    try
    {
        addRoom = connection.prepareStatement("INSERT INTO ROOMS (name,seats) VALUES (?,?)");
        addRoom.setString(1, name);
        addRoom.setInt(2, seats);
        addRoom.executeUpdate();
            txt += ("Room #" + name + " with " + seats + " seats has been added to possible rooms. \n");
            checkWaitlisted = connection.prepareStatement("SELECT * FROM WAITLIST");
            resultSet = checkWaitlisted.executeQuery();
            
            while(resultSet.next())
            {
                reservationNames.add(resultSet.getString(1));
                reservationDates.add(resultSet.getDate(2));
                reservationSeats.add(resultSet.getInt(3));
                reservationTimes.add(resultSet.getTimestamp(4));
            }
            for (int r = 0; r < reservationNames.size(); r++) {
                String facultyName = reservationNames.get(r);
                Date date = reservationDates.get(r);
                int waitlistedSeats = reservationSeats.get(r);
                Timestamp time = reservationTimes.get(r);
                
                WaitlistEntries waitlistEntry = new WaitlistEntries(facultyName, date, waitlistedSeats, time);
                WaitlistQueries.deleteWaitlistEntry(waitlistEntry);
            
                ReservationEntries entry = new ReservationEntries(facultyName, waitlistedSeats, date, time);
                int beforeAdd = ReservationQueries.totalReservations();
                ReservationQueries.addReservationEntry(entry);
                int afterAdd = ReservationQueries.totalReservations();
                
                if (beforeAdd < afterAdd) 
                {
                    txt += (facultyName + ", needing " + seats + " seats, has been taken off the waitlist and now reserves room " + name + " on Date " + date + "\n");
                }
            }
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return txt; 
   }
   
   public static String dropRoom(String name)
   {
      connection = DBConnection.getConnection();
      String txt = "";
      
      try
      {
          dropRoom = connection.prepareStatement("DELETE FROM ROOMS WHERE NAME = (?)");
          dropRoom.setString(1, name);
          dropRoom.executeUpdate();
      }
      catch(SQLException sqlException)
      {
          sqlException.printStackTrace();
      }
      txt += ReservationQueries.relocateByRoom(name);
      return txt;
   }
}