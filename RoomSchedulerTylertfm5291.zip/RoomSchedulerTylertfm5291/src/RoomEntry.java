/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */

//Room Entry class represents an entry in the room Table
public class RoomEntry
{
    private String name;
    private int seats;

//Constructor
public RoomEntry(String name, int seats)
{
    setName(name);
    setSeats(seats);
}

//set room name
public void setName(String name)
{
    this.name = name;
}

//get room name
public String getName()
{
    return name;
}

//set amount of seats
public void setSeats(int seats)
{
    this.seats = seats;
}

//get amount of seats
public int getSeats()
{
    return seats;
}

}

