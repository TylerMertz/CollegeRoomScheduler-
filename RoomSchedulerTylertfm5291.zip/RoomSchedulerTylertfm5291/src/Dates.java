import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.sql.Date;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */
public class Dates 
{
    private static Connection connection;
    private static ArrayList<Date> dates = new ArrayList<Date>();
    private static PreparedStatement addDate;
    private static PreparedStatement getDateList;
    private static ResultSet resultSet;
    
    //adding Date to Database
    public static void addDate(Date date)  
    {
        connection = DBConnection.getConnection();
        try
        {
            addDate = connection.prepareStatement("Insert into DATES (DATE) values (?)");
            addDate.setDate(1, date);
            addDate.executeUpdate();
        }
        
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
       
    }
    
    //gets entire date list
    public static ArrayList<Date> getDateList()
    {
        connection = DBConnection.getConnection();
        ArrayList<Date> dates = new ArrayList<Date>();
        try
        {
            getDateList = connection.prepareStatement("select DATE from DATES order by DATE");
            resultSet = getDateList.executeQuery();
            
            while(resultSet.next())
            {
                dates.add(resultSet.getDate(1));
            }
        }
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        
            return dates;
        
    }
}

