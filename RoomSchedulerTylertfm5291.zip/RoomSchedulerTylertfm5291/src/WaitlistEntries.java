import java.sql.Date;
import java.sql.Timestamp;

/*
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */
public class WaitlistEntries 
{
    
    private String facultyName;
    private Date date;
    private int seats;
    private Timestamp timeStamp;
    
    public WaitlistEntries(String facultyName, Date date, int seats, Timestamp timeStamp)
    {
        setFacultyName(facultyName);
        setSeats(seats);
        setDate(date);
        setTimeStamp(timeStamp);
    }

    public void setFacultyName(String facultyName) {
        this.facultyName = facultyName;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public void setTimeStamp(Timestamp timeStamp) {
        this.timeStamp = timeStamp;
    }

    public String getFacultyName() {
        return facultyName;
    }

    public Date getDate() {
        return date;
    }

    public int getSeats() {
        return seats;
    }

    public Timestamp getTimeStamp() {
        return timeStamp;
    }
    
}
