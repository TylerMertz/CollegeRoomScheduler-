import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */
public class WaitlistQueries {
    private static Connection connection;
    private static PreparedStatement getWaitlistByDate;
    private static PreparedStatement getWaitlistByFaculty;
    private static PreparedStatement addWaitlistEntry;
    private static PreparedStatement getFullWaitlist;
    private static PreparedStatement deleteWaitlistEntry;
    private static ArrayList<String> waitlisted = new ArrayList<String>();
    private static ResultSet resultSet;
    
    //adds waitlist entry 
    public static void addWaitlistEntry(WaitlistEntries waitlistEntry)
    {
        connection = DBConnection.getConnection();
        try
        {
            addWaitlistEntry = connection.prepareStatement("INSERT INTO WAITLIST (FACULTYNAME, DATE, SEATS, TIMESTAMP) values (?,?,?,?)");
            addWaitlistEntry.setString(1, waitlistEntry.getFacultyName());
            addWaitlistEntry.setDate(2, waitlistEntry.getDate());
            addWaitlistEntry.setInt(3, waitlistEntry.getSeats());
            addWaitlistEntry.setTimestamp(4, waitlistEntry.getTimeStamp());
            addWaitlistEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    //gets Waitlist Entries By Specific Date
    public static ArrayList<String> getWaitlistByDate(Date date)
    {
        
        connection = DBConnection.getConnection();
        waitlisted = new ArrayList<String>();
        try
        {
            getWaitlistByDate = connection.prepareStatement("SELECT FACULTYNAME,SEATS FROM WAITLIST where DATE = ? ORDER BY TIMESTAMP");
            getWaitlistByDate.setDate(1, date);
            resultSet = getWaitlistByDate.executeQuery();
            
            while(resultSet.next())
            {
                String txt = (resultSet.getString("FACULTYNAME") + " is waiting for a room with " + resultSet.getString("SEATS") + " seats for the date " + date);
                waitlisted.add(txt);
            }
        }
        catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
        return waitlisted;
    }
    
    //gets Waitlist Entries By Specific Faculty
    public static ArrayList<String> getWaitlistByFaculty(String facultyName)
    {
        
        connection = DBConnection.getConnection();
        waitlisted = new ArrayList<String>();
        try
        {
            getWaitlistByFaculty = connection.prepareStatement("SELECT DATE,SEATS FROM WAITLIST WHERE FACULTYNAME = ? ORDER BY TIMESTAMP");
            getWaitlistByFaculty.setString(1, facultyName);
            resultSet = getWaitlistByFaculty.executeQuery();
            
            while(resultSet.next())
            {
                String txt = (facultyName + " is waitlisted for a room on " + resultSet.getDate("DATE") + " with " + resultSet.getString("SEATS") + " seats");
                waitlisted.add(txt);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        return waitlisted;
    }
    
    //Retrieve full waitlist for display
    public static ArrayList<String> getFullWaitlist()
    {
        
        connection = DBConnection.getConnection();
        waitlisted = new ArrayList<String>();
        try
        {
            getFullWaitlist = connection.prepareStatement("SELECT DATE,FACULTYNAME,SEATS FROM WAITLIST ORDER BY DATE,TIMESTAMP");
            resultSet = getFullWaitlist.executeQuery();
            int placeinline = 0;
            
            while(resultSet.next())
            {
                placeinline += 1;
                String txt = (placeinline) +". "+ resultSet.getString("FACULTYNAME") + " is waitlisted for a room on " + resultSet.getDate("DATE") + " with " + resultSet.getString("SEATS") + " seats.";
                waitlisted.add(txt);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        return waitlisted;
        
    }
    
    //deletes waitlist Entry
    public static void deleteWaitlistEntry(WaitlistEntries entry) 
    {
        connection = DBConnection.getConnection();
        String facultyName = entry.getFacultyName();
        Date date = entry.getDate();
        try
        {
            deleteWaitlistEntry = connection.prepareStatement("DELETE FROM WAITLIST WHERE FACULTYNAME = (?) and DATE = (?)");
            deleteWaitlistEntry.setString(1, facultyName);
            deleteWaitlistEntry.setDate(2, date);
            deleteWaitlistEntry.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
}
