import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */
public class ReservationQueries {
    
   private static Connection connection;
   private static ArrayList<String> reservations = new ArrayList<String>();
   private static ArrayList<String> reservationNames = new ArrayList<String>();
   private static ArrayList<Integer> reservationSeats = new ArrayList<Integer>();
   private static ArrayList<Date> reservationDates = new ArrayList<Date>();
   private static ArrayList<Timestamp> reservationTimes = new ArrayList<Timestamp>();
   private static ResultSet resultSet;
   private static PreparedStatement getReservationsByDate;
   private static PreparedStatement getReservationsByFaculty;
   private static PreparedStatement totalReservations;
   private static PreparedStatement addReservationEntry;
   private static PreparedStatement getReservationsCheckByDate;
   private static PreparedStatement relocateByRoom;
   private static PreparedStatement deleteReservationByRoom;
   private static PreparedStatement checkWaitlist;
   private static PreparedStatement cancelReservationByNameAndDate;
   private static PreparedStatement cancelWaitlistByNameAndDate;
   
   private static PreparedStatement resetReservations;
   private static PreparedStatement resetWaitlist;
   private static PreparedStatement resetDates;
   private static PreparedStatement resetRooms;
   private static PreparedStatement resetFaculty;
   
   
        //adds a Reservation Entry    
        public static void addReservationEntry(ReservationEntries reservationEntry)
        {
            
            connection = DBConnection.getConnection();
            try
            {
                if (reservationEntry.getRoom().equals(""))
                {
                    WaitlistEntries waitlistEntry = new WaitlistEntries(reservationEntry.getFaculty(),reservationEntry.getDate(), 
                                                                        reservationEntry.getSeats(),reservationEntry.getTimestamp());
                    WaitlistQueries.addWaitlistEntry(waitlistEntry);
                }
                else 
                {
                addReservationEntry = connection.prepareStatement("INSERT into RESERVATIONS (FACULTYNAME, ROOM, DATE, SEATS, TIMESTAMP) values (?,?,?,?,?)");
                addReservationEntry.setString(1, reservationEntry.getFaculty());
                addReservationEntry.setString(2, reservationEntry.getRoom());
                addReservationEntry.setDate(3, reservationEntry.getDate());
                addReservationEntry.setInt(4, reservationEntry.getSeats());
                addReservationEntry.setTimestamp(5, reservationEntry.getTimestamp());
                addReservationEntry.executeUpdate();
                }  
            }     
            catch(SQLException sqlException)
                {
                    sqlException.printStackTrace();
                }
   
        }
        
        //Gets all Rooms Reservations by Date to check if room is occupied
        public static ArrayList<String> getReservationsByDate(Date date) 
        {
            connection = DBConnection.getConnection();
            reservations = new ArrayList<String>();
            try  
            { 
                getReservationsByDate = connection.prepareStatement("SELECT ROOM FROM RESERVATIONS WHERE DATE = ?");
                getReservationsByDate.setDate(1, date);
                resultSet = getReservationsByDate.executeQuery();
                
                while (resultSet.next())
                {
                    reservations.add(resultSet.getString("ROOM"));
                }
                
                return reservations;
            }
            catch(SQLException sqlException)
                {
                    sqlException.printStackTrace();
                }
            
            return reservations;
            
        } 
        
        //Gets reservations by date for check reservations
        public static ArrayList<String> getReservationsCheckByDate(Date date) {
        connection = DBConnection.getConnection();
        reservations = new ArrayList<String>();
        try
        {
            getReservationsCheckByDate = connection.prepareStatement("SELECT FACULTYNAME,ROOM FROM RESERVATIONS WHERE DATE = ?");
            getReservationsCheckByDate.setDate(1, date);
            resultSet = getReservationsCheckByDate.executeQuery();
            
            while(resultSet.next())
            {
                String txt = resultSet.getString("FACULTYNAME") + " reserved room #" + resultSet.getString("ROOM") + " for the date " + date;
                reservations.add(txt);
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        return reservations;
        }
        
                
        //Gets all Reservations by Faculty
        public static ArrayList<String> getReservationsByFaculty(String facultyName) 
        {
            connection = DBConnection.getConnection();
            reservations = new ArrayList<String>();
            try  
            { 
                getReservationsByFaculty = connection.prepareStatement("SELECT ROOM, DATE FROM RESERVATIONS WHERE FACULTYNAME = ?");
                getReservationsByFaculty.setString(1, facultyName);
                resultSet = getReservationsByFaculty.executeQuery();
                
                while (resultSet.next())
                {
                    String txt = (facultyName + " reserved room  #" + resultSet.getString("ROOM") + " for " + resultSet.getDate("DATE"));
                    reservations.add(txt);
                }    
            }
            catch(SQLException sqlException)
                {
                    sqlException.printStackTrace();
                }
            
            return reservations;
            
        } 
        
        
        //Gets total number of reservations
        public static int totalReservations()
        {
            connection = DBConnection.getConnection();
            reservations = new ArrayList<String>();
            try
            {
                
                totalReservations = connection.prepareStatement("SELECT FACULTYNAME FROM RESERVATIONS");
                resultSet = totalReservations.executeQuery();
                
                while(resultSet.next())
                {
                    reservations.add(resultSet.getString(1));
                }
            }
        
            catch(SQLException sqlException)
            {
                sqlException.printStackTrace();
            }
            return reservations.size();
        }
        
        //Iterates through reservations and Relocates reservations by room when room is removed
        public static String relocateByRoom(String room) {
        connection = DBConnection.getConnection();
        String txt = "";
        reservationNames = new ArrayList<String>();
        reservationSeats = new ArrayList<Integer>();
        reservationDates = new ArrayList<Date>();
        reservationTimes = new ArrayList<Timestamp>();
        try
        {
            relocateByRoom = connection.prepareStatement("SELECT FACULTYNAME,DATE,SEATS,TIMESTAMP FROM RESERVATIONS WHERE ROOM = (?)");
            relocateByRoom.setString(1, room);
            resultSet = relocateByRoom.executeQuery();
            
            while(resultSet.next())
            {
                reservationNames.add(resultSet.getString(1));
                reservationDates.add(resultSet.getDate(2));
                reservationSeats.add(resultSet.getInt(3));
                reservationTimes.add(resultSet.getTimestamp(4));
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        //calls Method inside of relocate by room to delete room from database 
        deleteReservationByRoom(room);
        txt += room + " has been removed.\n";
        for (int reservation = 0; reservation < reservationNames.size(); reservation++) 
          {
            ReservationEntries entry = new ReservationEntries(reservationNames.get(reservation), reservationSeats.get(reservation), reservationDates.get(reservation), reservationTimes.get(reservation));
            int beforeAdd = ReservationQueries.totalReservations();
            room = entry.getRoom();
            addReservationEntry(entry);
            int afterAdd = ReservationQueries.totalReservations();
            if (beforeAdd < afterAdd) 
            {
                txt += (reservationNames.get(reservation)+ " has now reserved room " + room + " with " + reservationSeats.get(reservation) + " seats for the date " + reservationDates.get(reservation) +  "\n");
            }
            else  
            {
                    txt += (reservationNames.get(reservation)+ " has been waitlisted for a room with " + reservationSeats.get(reservation) + " seats for "  + reservationDates.get(reservation) + ". \n");
            }
          }
            return txt;
        }
        
                
    //Deletes reservation by room 
    public static void deleteReservationByRoom(String name) 
    {
        connection = DBConnection.getConnection();
        try
        {
            deleteReservationByRoom = connection.prepareStatement("DELETE from reservations WHERE room = (?)");
            deleteReservationByRoom.setString(1, name);
            deleteReservationByRoom.executeUpdate();
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
    }
    
    //Deletes reservation by faculty name and date
    public static String cancelReservationByNameAndDate(String name, Date date) 
    {
        connection = DBConnection.getConnection();
        String txt = "";
        String room = "";
        reservationNames = new ArrayList<String>();
        reservationSeats = new ArrayList<Integer>();
        reservationDates = new ArrayList<Date>();
        reservationTimes = new ArrayList<Timestamp>();
        
        
        try
        {
            cancelReservationByNameAndDate = connection.prepareStatement("DELETE FROM RESERVATIONS WHERE FACULTYNAME = (?) and DATE = (?)");
            cancelReservationByNameAndDate.setString(1, name);
            cancelReservationByNameAndDate.setDate(2, date);
            int beforeDelete = ReservationQueries.totalReservations();
            cancelReservationByNameAndDate.executeUpdate();
            int afterDelete = ReservationQueries.totalReservations();
            if (afterDelete < beforeDelete)
            {
                txt += " ";
            }
            
            cancelWaitlistByNameAndDate = connection.prepareStatement("DELETE FROM WAITLIST WHERE FACULTYNAME = (?) and DATE = (?)");
            cancelWaitlistByNameAndDate.setString(1, name);
            cancelWaitlistByNameAndDate.setDate(2, date);
            cancelWaitlistByNameAndDate.executeUpdate();
            
            
            checkWaitlist = connection.prepareStatement("SELECT * FROM WAITLIST");
            resultSet = checkWaitlist.executeQuery();
            
            while(resultSet.next())
            {
                reservationNames.add(resultSet.getString(1));
                reservationDates.add(resultSet.getDate(2));
                reservationSeats.add(resultSet.getInt(3));
                reservationTimes.add(resultSet.getTimestamp(4));
            }
            
            for (int reservation = 0; reservation < reservationNames.size(); reservation++) 
            {
                String faculty = reservationNames.get(reservation);
                Date date2 = reservationDates.get(reservation);
                int seats = reservationSeats.get(reservation);
                Timestamp time = reservationTimes.get(reservation);
                
                WaitlistEntries waitlistEntry = new WaitlistEntries(faculty, date2, seats, time);
                WaitlistQueries.deleteWaitlistEntry(waitlistEntry);
            
                ReservationEntries entry = new ReservationEntries(faculty, seats, date2, time);
                room = entry.getRoom();
                
                int beforeAdd = ReservationQueries.totalReservations();
                ReservationQueries.addReservationEntry(entry);
                int afterAdd = ReservationQueries.totalReservations();
                
                if (beforeAdd < afterAdd) 
                {
                    txt += (faculty + " has been removed from the waitlist and is now reserved for room "+ room + " with " + seats+ " seats on date " + date2 + ". \n");
                }
            }
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        return txt;
    }
    
    //RESETS ENTIRE DATABASE FOR TESTING PURPOSES
    public static String resetDatabase()
    {
        connection = DBConnection.getConnection();
        String txt = "Database has been cleared.";
        try
        {
            resetReservations = connection.prepareStatement("DELETE FROM RESERVATIONS");
            resetReservations.executeUpdate();
            
            resetWaitlist = connection.prepareStatement("DELETE FROM WAITLIST");
            resetWaitlist.executeUpdate();
            
            resetDates = connection.prepareStatement("DELETE FROM DATES");
            resetDates.executeUpdate();
            
            resetRooms = connection.prepareStatement("DELETE FROM ROOMS");
            resetRooms.executeUpdate();
            
            resetFaculty = connection.prepareStatement("DELETE FROM FACULTY");
            resetFaculty.executeUpdate();
            
        }
        catch(SQLException sqlException)
        {
            sqlException.printStackTrace();
        }
        
        return txt;
    }
        
}
