import java.sql.Date;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import javax.swing.table.DefaultTableModel;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author tylermertz
 */

//Reservation Entry class represents an Entry in the Reservation Table
public class ReservationEntries 
{
    private ArrayList<String> rooms;
    private ArrayList<String> reservedRooms;
    private String faculty;
    private int seats;
    private Date date;
    private String room;
    private Timestamp timestamp;
    
    //Constructor
    public ReservationEntries(String faculty, int seats, Date date, Timestamp timestamp)
    {
        setFaculty(faculty);
        setSeats(seats);
        setDate(date);
        setTimestamp(timestamp);
        
    }
    
    //Getters and setters
    public String getFaculty() {
        return faculty;
    }

    public void setFaculty(String faculty) {
        this.faculty = faculty;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
    //Finds possible rooms
    public String getRoom() {
        rooms = RoomQueries.getAllPossibleRooms(seats);
        reservedRooms = ReservationQueries.getReservationsByDate(date);
        if (reservedRooms.isEmpty())
        {
            if (rooms.isEmpty())
            {
                return "";
            }
            
            return rooms.get(0);
        }
        
        for (String room : rooms)
        {
            if (!(reservedRooms.contains(room))) {
                
                return room;
            }
        }
        
        return "";
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
    
    
}
